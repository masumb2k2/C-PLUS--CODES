ID: 0812110205171001

#include<iostream>
using namespace std;
int main()
{
int n,i=0;
cout<<"Enter The Value of N=";
cin>>n;
int arr[n];
while(n!=0){
for(int i=0;i<n;i++){
cout<<"enter "<<i <<"array Element =  ";
cin>>arr[i];
}
//print forward
for(int i=0;i<n;i++){
//cout<<i <<" th array element is ="<<arr[i]<<endl;
if(arr[i]%2==0 && arr[i]%3==0){
continue;
}
else{
cout<< i <<" th array element is ="<<arr[i]<<endl;
}


}

cout<<"reverse Order"<<endl;

//print reverse
for(int i=n-1;i>=0;i--){
//cout<<i <<" th array element is ="<<arr[i]<<endl;
if(arr[i]%2==0 && arr[i]%3==0){
continue;
}
else{
cout<< i <<" th array element is ="<<arr[i]<<endl;
}


}
cout<<"Enter The Value of N=";
cin>>n;
i++;
}


}

