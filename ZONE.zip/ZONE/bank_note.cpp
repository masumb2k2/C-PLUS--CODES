//Id:0812110205171001

#include<iostream>
using namespace std;
int main()
{
int money;

while(true){
cout<<"Enter AMount To Pay:";
cin>>money;
if(money==0){
break;

}
else{
cout<<"Note of 1000 tk:"<<money/1000<<endl;
int extra1=money%1000;
if(extra1!=0){
 cout<<"Note of 500 tk:"<<extra1/500<<endl;
 int extra2=extra1%500;
 if(extra2!=0){
 cout<<"Note of 100 tk:"<<extra2/100<<endl;
 int extra3=extra2%100;
 if(extra3!=0){
 cout<<"Note of 50 tk:"<<extra3/50<<endl;
 int extra4=extra3%50;
 if(extra4!=0){
 cout<<"Note of 20 tk:"<<extra4/20<<endl;
 int extra5=extra4%20;
 if(extra5!=0){
 cout<<"Note of 10 tk:"<<extra5/10<<endl;
 int extra6=extra5%10;
 if(extra6!=0){
 cout<<"Note of 5 tk:"<<extra6/5<<endl;
 int extra7=extra6%5;
 if(extra7!=0){
 cout<<"Note of 2 tk:"<<extra7/2<<endl;
 int extra8=extra7%2;
 if(extra8!=0){
 cout<<"Note of 1 tk:"<<extra8/1<<endl;
 ;

 }

 }

 }

 }

 }

 }
 }
}


}

}


}
