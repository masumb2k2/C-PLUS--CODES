#include<iostream>
using namespace std;
//ID:0812110205171001
class student  {
  public:
    int id;
    string name;
    int session;



};

int main() {
  student masum;

  masum.id = 01;
  masum.name = "masum billah";
  masum.session=2020;

  cout << masum.id << endl;
  cout << masum.name<<endl;
  cout << masum.session<<endl;


student mamun;

  mamun.id = 04;
  mamun.name = "mamun";
  mamun.session=2020;

  cout << mamun.id << endl;
  cout << mamun.name<<endl;
  cout << mamun.session<<endl;


}

