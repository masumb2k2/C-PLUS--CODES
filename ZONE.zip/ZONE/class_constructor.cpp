#include<iostream>
#include<cstring>
using namespace std;
//ID:0812110205171001
class student  {
  public:
    int id;
    string name;
    int session;

student(int i,string a,int s){
    name=a;
    id =i;
    session=s;
    cout<<a<<endl;
    cout<<i<<endl;
    cout<<s<<endl;

    }



};

int main() {
  student masum(01,"masum",2020);




}


