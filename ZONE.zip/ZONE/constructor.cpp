#include <iostream>
using namespace std;

//ID:0812110205171001
class class1 {
public:
int x;
class1 (int i);
};
class1::class1 (int i) {
x = i;
}
class class2 {
public:
int y;
class2 ();
};
class2::class2 () {
int y = 7;
}

int main () {
class1 a1(20);
class2 a2;
cout<< a1.x <<endl;
cout<< a2.y <<endl;

}
