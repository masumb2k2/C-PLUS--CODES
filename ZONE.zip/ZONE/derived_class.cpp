#include<iostream>
using namespace std;
//ID:0812110205171001
#include<iostream>
using namespace std;

class student  {
  public:
    int id;
  private:
    string name;
  protected:
    int session;
  class drived:public



};

int main() {
  student masum;

  masum.id = 01;
  masum.name = "masum billah";
  masum.session=2020;



;


}

