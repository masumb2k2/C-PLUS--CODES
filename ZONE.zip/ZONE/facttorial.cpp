ID: 0812110205171001

#include<iostream>
using namespace std;
int main()
{
int n,fact=1,factval;
cout<<"Enter the Value of N=";
cin>>n;
for(int i=n;i>0;i--){
fact=fact*i;



}
cout<<"Factorial Value= "<<fact;

}
