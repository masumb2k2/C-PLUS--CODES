ID: 0812110205171001

#include <iostream>
using namespace std;

int main() {
    int n, first = 0, second = 1, next = 0;

    cout << "Enter the  Value of N = ";
    cin >> n;

    cout << "Fibonacci Series is =";

    for (int i = 1; i <= n; ++i) {

        if(i == 1) {
            cout << first<<"\t";
            continue;
        }
        if(i == 2) {
            cout << second <<"\t";
            continue;
        }
        next = first + second;
        first = second;
        second = next;

        cout << next << "\t";
    }

}
