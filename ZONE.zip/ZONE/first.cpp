//ID:0812110205171001

#include<iostream>
using namespace std;
int main()
{
int i,n,largest,loc,j;
cout<<"Enter rhe value of N:";
cin>>n;
int arr[n];
cout<<"enter "<<n<<"array element";
for (i=0;i<n;i++)
{
cin>>arr[i];
}
largest=arr[0];
for(j=1;j<n;j++)
{
if(arr[j]>largest){
largest=arr[j];
loc=j;
}
}
cout<<largest<<"is the largest number"<<endl;
cout<<"it is in "<<loc+1<<"the place"<<endl;
}
