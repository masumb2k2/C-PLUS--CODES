ID: 0812110205171001

#include <iostream>
using namespace std;


int absolute(int val){
    if (val < 0)
        val = -val;
    return val;
}


float absolute(float val) {
     if (val < 0.0)
         val = -val;
    return val;
}

int main() {


    cout << "Absolute value of -9 = " << absolute(-9) << endl;


    cout << "Absolute value of 9.8 = " << absolute(-9.8f) << endl;
    return 0;
}
