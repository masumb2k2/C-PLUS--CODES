//ID:0812110205171001

#include<iostream>
using namespace std;
int main()
{
int sh,sm,ss;
cout<<" enter starting hour :";
cin>>sh;
cout<<" enter starting minute :";
cin>>sm;
cout<<" enter starting second :";
cin>>ss;
int fh,fm,fs;

cout<<" enter finishing hour :";
cin>>fh;
cout<<" enter finishing minute :";
cin>>fm;
cout<<" enter finishing second :";
cin>>fs;

int shtos=sh*3600;
int smtos=(sm+1)*60;
int sfinal_s=shtos+smtos+ss;

int fhtos=fh*3600;
int fmtos=(fm+1)*60;
int ffinal_s=fhtos+fmtos+fs;

int dur=ffinal_s-sfinal_s;


cout<<"Duration Hour:"<<dur/3600<<endl;
int extra1=dur%3600;
if(extra1!=0){
cout<<"Duration  Minute:"<<extra1/60<<endl;
cout<<"Duration Second:"<<extra1%60<<endl;
}





}
