
//ID: 0812110205171001

#include<iostream>
using namespace std;
int main()
{
int num;
cout<<"Enter how much you want=\t";
cin>>num;
if (num==1 || num==2||num==4||num==5||num==8||num==11){
    cout<<"Not Possible";
}
else{
    cout<<"Possible";
}


}
