#include <iostream>
using namespace std;
//ID:0812110205171001


class father {
   public:
    void print() {
        cout << "masum billah" << endl;
    }
};

class child : public father {
   public:
    void print() {
        cout << "billah masum" << endl;
    }
};

int main() {
     child chob;
    chob.print();

}
