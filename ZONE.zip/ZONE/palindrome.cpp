#include<iostream>
#include<cstring>
using namespace std;


//ID: 0812110205171001

int main()
{
        char str[30];

        int  flag = 0;

        cout<<" Enter  the String : \t";
        cin>>str;

        for(int i=0;i < strlen(str) ;i++)
        {
                if(str[i] != str[strlen(str)-i-1])
                {
                        flag = 1;
                        break;
                }
        }
        if(flag)
        {
                cout<<" "<<str<<" is not a palindrome"<<endl;
        }
        else
        {
                cout<<" "<<str<< " is a palindrome"<<endl;
        }

}
