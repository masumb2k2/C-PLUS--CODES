#include<iostream>
using namespace std;

//ID: 0812110205171001

void f(int ,float,int&);

int main(){
int a=10,c=30;
float b=20.22;
cout<<"a= "<<a<<" ,b= "<<b<<" ,c= "<<c<<endl;
f(a,b,c);
cout<<"a= "<<a<<" ,b= "<<b<<" ,c= "<<c<<endl;
f(a*3,b-4,c);
cout<<"a= "<<a<<" ,b= "<<b<<" ,c= "<<c<<endl;

}

void f(int x,float y, int& z){
x=44;
y=55.22;
z=77;

}
