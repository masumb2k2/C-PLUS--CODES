#include<iostream>
using namespace std;

class grand{
public:int a=2;
protected:int b=3;
private:int c=1;

};
class father :public grand{
public:int x=7;
protected:int y=8;
private:int z=9;

};
class child:public father{
public:int p=11;
private:int q=12;
protected:int r;
public:void set_value(int t){
r=t;
cout<<r;
};

};

int main(){
child chob;
chob.set_value(5);



}


