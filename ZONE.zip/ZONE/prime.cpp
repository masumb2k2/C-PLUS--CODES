
//ID: 0812110205171001

#include<iostream>
using namespace std;
int main()
{
    int i, check=0, j;
    cout<<"numbers are=   2\t";
    for(i=1; i<=100; i++)
    {
        if(i%2!=0){
            for(j=2; j<i; j++)
        {
           if(i%j==0)
           {
               check++;
               break;
           }
        }
        if(check==0 && i!=1)
            cout<<i<<'\t';
        check = 0;

        }

    }
}
