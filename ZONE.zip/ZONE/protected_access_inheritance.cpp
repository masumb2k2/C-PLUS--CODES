#include<iostream>
using namespace std;
//ID:0812110205171001
class grand
{
    private: int a;
    protected:int b;
    public: int c;

};
class father:public grand
{
    private:int p=6;
    protected: int q=7;
    public: int r;

};

class child:public father
{
    private:int x;
    protected: int y;
    public: int z;
    public: void disproc(int a){
        y=a;
    cout<<y<<endl;
    }


};

int main()
{
    child chob;
    chob.disproc(5);
    //cout<<"Value=\t"<<val<<endl;


}
