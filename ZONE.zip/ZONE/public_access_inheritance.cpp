#include<iostream>
using namespace std;
//ID:0812110205171001
class grand
{
    private: int a;
    protected:int b;
    public: int c;

};
class father:public grand
{
    private:int p=6;
    protected: int q=7;
    public: int r;

};

class child:public father
{
    private:int x;
    protected: int y;
    public: int z;



};

int main()
{
    child chob;
    int val=chob.c=7;
    cout<<"Value=\t"<<val<<endl;


}
