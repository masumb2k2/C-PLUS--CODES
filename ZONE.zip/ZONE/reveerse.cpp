
#include<iostream>
#include<cstring>
using namespace std;


//ID: 0812110205171001

int main()
{
    char str[20];
    cout<< "Enter the String: ";
    cin>>str;



    for(int  i=strlen(str);i>=0;i--){


        cout<<str[i];

    }


}
