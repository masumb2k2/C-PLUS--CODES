//ID:0812110205171001

#include<iostream>
using namespace std;
int main()
{
int n,felement;
cout<<"Enter ELment Number of Array:";
cin>>n;
int arr[n];
cout<<"enter Array Elment:";
for(int i=0;i<n;i++){
cin>>arr[i];
}
cout<<"Finding Element:";
cin>>felement;
for(int i=0;i<n;i++){
if(arr[i]==felement){
cout<<felement <<" found at the location of :"<<i<<endl;
}
else{
cout<<"Element Not Found ";
}
}


}
