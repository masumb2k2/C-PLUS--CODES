ID: 0812110205171001
#include<iostream>
using namespace std;
int main()
{

int sum=0,n,init,last;

cout<<"Enter The Initial Value =";
cin>>init;
cout<<"Enter The Last  Value =";
cin>>last;
for(int i=init;i<=last;i=i+2){
sum=sum+i;
}
cout<<"Sum Value is ="<<sum<<endl;
}
