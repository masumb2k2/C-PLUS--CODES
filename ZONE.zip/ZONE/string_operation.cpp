
#include<iostream>
#include<cstring>
using namespace std;

//ID: 0812110205171001

int main () {
	   string string1 = "Department  ";
	   string string2 = "of ";
	   string string3 = "ICE";
	   string string4 = string1 + string2 + string3;
	   int  len = string4.length();


	   cout << string4 << endl;

	   cout << "Length of string1 is: " << len <<endl;

	   cout <<"Expert is at position " << string2.find("of") <<endl;

	   cout << "Part of string 2: " << string2.substr(3,8)<<endl;

	   cout << "Replacing 'of':  " << string4.replace(12, 17, "by")<<endl;

	   cout << "Insertion:  "<< string4.insert(0, " of bauet")<<endl;

	   cout << "Erasing:  " << string3.erase(0,3)<<endl;

	   return 0;
}
