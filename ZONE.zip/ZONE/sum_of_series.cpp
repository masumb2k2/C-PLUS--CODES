ID: 0812110205171001

#include<iostream>
using namespace std;
int main()
{
cout<<"Enter the value of N=";
int sum=0,n;
cin>>n;
for(int i=1;i<=n;i=i+2){
sum=sum+i;
}
cout<<"Sum Value is ="<<sum<<endl;
}
