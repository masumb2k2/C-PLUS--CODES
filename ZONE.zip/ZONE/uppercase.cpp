
#include<iostream>
#include<cstring>
using namespace std;


//ID: 0812110205171001

int main()
{
    char str[20];
    cout<< "Enter the String: ";
    cin>>str;



    for(int i=0;i<=strlen(str);i++){

        if(str[i]>=97 && str[i]<=122){
            str[i]=str[i]-32;
        }
        cout<<str[i];

    }


}
