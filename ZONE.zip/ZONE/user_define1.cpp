#include<iostream>
using namespace std;
//ID: 0812110205171001
int cube(int x){
return x*x*x;
}

int main(){
int n=1;
while(n!=0){
    cin>>n;
    cout<<"cube of "<<n<<"  is =  "<<cube(n)<<endl;

}

}
