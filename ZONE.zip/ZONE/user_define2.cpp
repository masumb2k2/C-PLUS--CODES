#include<iostream>
using namespace std;

int max (int ,int);


//ID: 0812110205171001

int main(){
int m,n;
while (m!=0){
    cin>>m>>n;
    cout<<"max value of "<<m<<" & "<<n <<" is = "<<max(m,n)<<endl;


}

}
int max(int x,int y){
if (x>y)
    return x;
else
return y;
}
