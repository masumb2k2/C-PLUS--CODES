#include<iostream>
using namespace std;

//ID: 0812110205171001

int age(){
int n;
while (true){
    cout<<"Enter your age =";
    cin>>n;
    if (n<0){
        cout<<"Age couldn't be negative";
    }
    else if(n>120){
        cout<<"age Could not over 120";
    }
    else{
        return n;
        cout<<"Try Again";
    }
}

}

int main(){
int a=age();
cout<<"your age = "<<a<<endl;

}
