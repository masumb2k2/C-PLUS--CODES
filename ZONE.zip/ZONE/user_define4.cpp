#include<iostream>
using namespace std;

//ID: 0812110205171001

void f(int,int&);

int main(){
int a =22,b=44;
cout<<"a = "<<a<<" , b= "<<b<<endl;
f(a,b);
cout<<"a = "<<a<<" , b= "<<b<<endl;
f(2*a-3,b);
cout<<"a = "<<a<<" , b= "<<b<<endl;

}
void f(int x,int& y)
{
    x=88;
    y=99;

}
