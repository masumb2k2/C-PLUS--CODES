
//ID: 0812110205171001

#include<iostream>
using namespace std;
int main(){
cout<<"Enter The Number=  ";
int num;
cin>>num;
for (int i=1;i<=num;i++){
    if(num%i==0){
        cout<<"possible by="<<i<<endl;
    }
}



}
